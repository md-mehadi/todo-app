function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}

function myFunctions() {
    var x = document.getElementById("ip1");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
    var x2 = document.getElementById("ip2");
    if (x2.type === "password") {
        x2.type = "text";
    } else {
        x2.type = "password";
    }
}